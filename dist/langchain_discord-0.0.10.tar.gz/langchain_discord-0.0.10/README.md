A list of tools for LangChain to power Discord (Webhooks, etc.).
